<?php
session_start();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $data=json_decode(file_get_contents('php://input'),true);
  $_SESSION['cart']=is_array($data)?$data:[];
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok'=>true,'cart'=>$_SESSION['cart']??[]]);
