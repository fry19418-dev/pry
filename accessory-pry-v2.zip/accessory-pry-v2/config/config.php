<?php
return [
  'site_name' => 'اکسسوری پری',
  'site_url' => 'https://YOUR-DOMAIN.ir',
  'currency' => 'IRT',
  'admin_user' => 'admin',
  'admin_password' => 'CHANGE-THIS-PASSWORD',
  'shipping_fee' => 65000,
  'zarinpal' => ['merchant_id' => 'YOUR-ZARINPAL-MERCHANT-ID', 'sandbox' => false],
  'instagram' => '@pry_706',
];
