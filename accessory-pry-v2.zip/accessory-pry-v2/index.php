<?php
session_start();
$config=require __DIR__.'/config/config.php';
$products=json_decode(file_get_contents(__DIR__.'/storage/products.json'),true) ?: [];
$cats=array_values(array_unique(array_column($products,'category')));
function toman($n){return number_format((int)$n).' تومان';}
$cart=$_SESSION['cart']??[];
$cartCount=array_sum($cart);
?><!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>اکسسوری پری | فروشگاه آنلاین اکسسوری</title>
<meta name="description" content="فروشگاه آنلاین اکسسوری پری؛ زیورآلات و اکسسوری‌های خاص با ارسال سریع و بسته‌بندی شیک.">
<link rel="icon" href="assets/logo.png"><link rel="stylesheet" href="assets/style.css">
</head><body>
<header class="top"><div class="container nav"><a class="brand" href="index.php"><img src="assets/logo.png"><span>اکسسوری پری</span></a><nav><a href="#shop">فروشگاه</a><a href="#cats">دسته‌بندی</a><a href="#about">درباره ما</a><a href="#contact">تماس</a></nav><button class="cart-btn" onclick="openCart()">🛒 سبد خرید <b id="cartCount"><?=$cartCount?></b></button></div></header>
<main>
<section class="hero container"><img src="assets/hero.png" alt="اکسسوری پری" class="hero-img"><div class="hero-overlay"><span>جدیدترین انتخاب‌ها</span><h1>استایل تو، امضای تو ✨</h1><p>اکسسوری‌های خاص برای خاص‌ترین آدم‌ها.</p><a class="btn" href="#shop">مشاهده محصولات</a></div></section>
<section class="features container"><div>✨ <b>کیفیت بالا</b><small>انتخاب‌شده با وسواس</small></div><div>🚚 <b>ارسال سریع</b><small>بسته‌بندی شیک و امن</small></div><div>🛡️ <b>ضمانت اصالت</b><small>خرید با خیال راحت</small></div><div>🎁 <b>مناسب هدیه</b><small>برای عزیزانت خاص باش</small></div></section>
<section id="cats" class="container section"><div class="section-title"><span>دسته‌بندی محصولات</span><h2>انتخاب کن و بدرخش</h2></div><div class="cat-grid"><?php foreach($cats as $c):?><a href="#shop" onclick="filterCat('<?=htmlspecialchars($c,ENT_QUOTES)?>')" class="cat">💎 <span><?=$c?></span></a><?php endforeach;?></div></section>
<section id="shop" class="container section"><div class="section-title"><span>پیشنهادهای پری</span><h2>محصولات محبوب</h2></div><div class="filters"><input id="search" placeholder="جستجوی محصول..." oninput="renderProducts()"><select id="category" onchange="renderProducts()"><option value="">همه دسته‌ها</option><?php foreach($cats as $c):?><option><?=$c?></option><?php endforeach;?></select></div><div id="products" class="product-grid"></div></section>
<section id="about" class="about container"><div><span>درباره اکسسوری پری</span><h2>زیبایی تو، استایل تو، اکسسوری خاص تو</h2><p>در اکسسوری پری تلاش می‌کنیم انتخاب اکسسوری را برایت ساده، لذت‌بخش و خاص کنیم؛ از گوشواره و گردنبند تا ساعت، عینک و اکسسوری مو.</p></div><img src="assets/logo.png" alt="لوگوی اکسسوری پری"></section>
<section id="contact" class="container contact"><h2>با پری در ارتباط باش 💕</h2><p>اینستاگرام: <b>@pry_706</b></p><p>پشتیبانی سفارش‌ها: هر روز ۹ تا ۲۱</p></section>
</main>
<footer><div class="container">© <?=date('Y')?> اکسسوری پری — همه حقوق محفوظ است.</div></footer>
<div id="drawer" class="drawer"><div class="drawer-head"><h3>سبد خرید</h3><button onclick="closeCart()">×</button></div><div id="cartItems"></div><div class="cart-total">مجموع: <b id="cartTotal">0</b></div><a class="btn full" href="checkout.php">ادامه و ثبت سفارش</a></div><div id="backdrop" class="backdrop" onclick="closeCart()"></div>
<script>const PRODUCTS=<?=json_encode($products,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?>; let cart=<?=json_encode($cart)?>;</script><script src="assets/app.js"></script>
</body></html>
