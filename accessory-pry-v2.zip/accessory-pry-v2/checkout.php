<?php
session_start();
$config=require __DIR__.'/config/config.php';
$products=json_decode(file_get_contents(__DIR__.'/storage/products.json'),true)?:[];
$cart=$_SESSION['cart']??[];$items=[];$subtotal=0;
foreach($cart as $id=>$q){$q=max(0,(int)$q);foreach($products as $p){if((string)$p['id']===(string)$id&&$q>0&&$p['active']&&$p['stock']>0){$q=min($q,(int)$p['stock']);$items[]=['p'=>$p,'q'=>$q];$subtotal += $p['price']*$q;}}}
if(!$items){header('Location:index.php');exit;}
function toman($n){return number_format((int)$n).' تومان';}
$coupons=json_decode(file_get_contents(__DIR__.'/storage/coupons.json'),true)?:[];
$discount=0;$couponMsg='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['coupon'])){
 $code=strtoupper(trim($_POST['coupon']));foreach($coupons as $c){if($c['active']&&$c['code']===$code){$discount=$c['type']==='percent'?round($subtotal*$c['value']/100):min($subtotal,(int)$c['value']);$_SESSION['coupon']=$c;break;}}
 if($discount)$couponMsg='کد تخفیف اعمال شد.'; else $couponMsg='کد تخفیف معتبر نیست.';
}
if(isset($_SESSION['coupon'])){$c=$_SESSION['coupon'];$discount=$c['type']==='percent'?round($subtotal*$c['value']/100):min($subtotal,(int)$c['value']);}
$total=$subtotal-$discount+$config['shipping_fee'];
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ثبت سفارش | اکسسوری پری</title><link rel="stylesheet" href="assets/style.css"></head><body><header class="top"><div class="container nav"><a class="brand" href="index.php"><img src="assets/logo.png"><span>اکسسوری پری</span></a><a href="index.php">بازگشت به فروشگاه</a></div></header><main class="container checkout-grid"><section class="form"><h1>تکمیل سفارش</h1><input name="dummy" style="display:none"><form method="post" class="coupon"><input name="coupon" placeholder="کد تخفیف"><button class="btn secondary">اعمال</button></form><?php if($couponMsg):?><div class="notice"><?=$couponMsg?></div><?php endif;?><form method="post" action="payment/request.php"><input name="name" required placeholder="نام و نام خانوادگی"><input name="mobile" required pattern="09[0-9]{9}" placeholder="شماره موبایل"><input name="email" type="email" placeholder="ایمیل (اختیاری)"><textarea name="address" required rows="4" placeholder="آدرس کامل برای ارسال"></textarea><input name="postal" pattern="[0-9]{10}" placeholder="کد پستی ۱۰ رقمی"><input type="hidden" name="coupon" value="<?=htmlspecialchars($_SESSION['coupon']['code']??'')?>"><button class="btn full" type="submit">پرداخت آنلاین</button></form></section><aside class="summary"><h2>خلاصه سفارش</h2><?php foreach($items as $it):?><div class="summary-row"><span><?=$it['p']['name']?> × <?=$it['q']?></span><b><?=toman($it['p']['price']*$it['q'])?></b></div><?php endforeach;?><hr><div class="summary-row"><span>جمع محصولات</span><b><?=toman($subtotal)?></b></div><div class="summary-row"><span>تخفیف</span><b><?=toman($discount)?></b></div><div class="summary-row"><span>ارسال</span><b><?=toman($config['shipping_fee'])?></b></div><div class="summary-total"><span>مبلغ نهایی</span><b><?=toman($total)?></b></div></aside></main></body></html>
