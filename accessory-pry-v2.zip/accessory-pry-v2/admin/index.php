<?php
session_start();
$config=require __DIR__.'/../config/config.php';
function go($url='index.php'){header('Location:'.$url);exit;}
function loadj($f,$d=[]){return file_exists($f)?(json_decode(file_get_contents($f),true)?:$d):$d;}
function savej($f,$d){file_put_contents($f,json_encode($d,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),LOCK_EX);}
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
$pf=__DIR__.'/../storage/products.json';$of=__DIR__.'/../storage/orders.json';$cf=__DIR__.'/../storage/coupons.json';
if(isset($_GET['logout'])){session_destroy();go();}
if(!isset($_SESSION['admin'])){
  if($_SERVER['REQUEST_METHOD']==='POST'&&hash_equals((string)$config['admin_user'],(string)($_POST['u']??''))&&hash_equals((string)$config['admin_password'],(string)($_POST['p']??''))) $_SESSION['admin']=1;
  else { ?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ورود مدیریت</title><link rel="stylesheet" href="../assets/style.css"></head><body><form class="form admin-login" method="post"><img src="../assets/logo.png"><h2>مدیریت اکسسوری پری</h2><input name="u" placeholder="نام کاربری"><input name="p" type="password" placeholder="رمز عبور"><button class="btn">ورود</button></form></body></html>
<?php exit; }
}
$products=loadj($pf);$orders=loadj($of);$coupons=loadj($cf);$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $action=$_POST['action']??'';
 if($action==='save_product'){
   $id=(int)($_POST['id']??0);
   $p=['id'=>$id?:((int)(max(array_column($products,'id')?:[0]))+1),'name'=>trim($_POST['name']??''),'category'=>trim($_POST['category']??''),'price'=>(int)($_POST['price']??0),'old_price'=>(int)($_POST['old_price']??0),'stock'=>(int)($_POST['stock']??0),'description'=>trim($_POST['description']??''),'active'=>isset($_POST['active']),'image'=>trim($_POST['image']??'assets/hero.png')];
   $found=false;foreach($products as &$x){if($x['id']===$p['id']){$x=$p;$found=true;break;}}unset($x);if(!$found)$products[]=$p;savej($pf,$products);$msg='محصول ذخیره شد.';
 }
 if($action==='delete_product'){$id=(int)$_POST['id'];$products=array_values(array_filter($products,fn($p)=>$p['id']!==$id));savej($pf,$products);$msg='محصول حذف شد.';}
 if($action==='status_order'){$id=$_POST['id']??'';foreach($orders as &$o){if($o['id']===$id)$o['status']=$_POST['status']??$o['status'];}unset($o);savej($of,$orders);$msg='وضعیت سفارش تغییر کرد.';}
 if($action==='coupon'){$code=strtoupper(trim($_POST['code']??''));if($code){$coupons[]=['code'=>$code,'type'=>($_POST['type']??'percent')==='fixed'?'fixed':'percent','value'=>(int)($_POST['value']??0),'active'=>true];savej($cf,$coupons);$msg='کد تخفیف اضافه شد.';}}
}
$edit=null;if(isset($_GET['edit']))foreach($products as $p)if($p['id']==(int)$_GET['edit'])$edit=$p;
$eid=h($edit['id']??0);$ename=h($edit['name']??'');$ecat=h($edit['category']??'');$eprice=h($edit['price']??'');$eold=h($edit['old_price']??'');$estock=h($edit['stock']??0);$eimage=h($edit['image']??'assets/hero.png');$edesc=h($edit['description']??'');$eactive=($edit['active']??true)?'checked':'';
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>پنل مدیریت | اکسسوری پری</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<header class="top"><div class="container nav"><b>پنل مدیریت اکسسوری پری</b><div><a href="../index.php">مشاهده فروشگاه</a> · <a href="?logout=1">خروج</a></div></div></header>
<main class="container section">
<?php if($msg):?><div class="notice success"><?=h($msg)?></div><?php endif;?>
<div class="admin-grid"><div class="stat"><small>محصولات</small><h2><?=count($products)?></h2></div><div class="stat"><small>سفارش‌ها</small><h2><?=count($orders)?></h2></div><div class="stat"><small>کدهای تخفیف</small><h2><?=count($coupons)?></h2></div><div class="stat"><small>درگاه</small><h2><?=str_contains($config['zarinpal']['merchant_id'],'YOUR-')?'تنظیم نشده':'فعال'?></h2></div></div>
<div class="admin-two">
<section><h2><?= $edit?'ویرایش محصول':'افزودن محصول'?></h2><form class="form compact" method="post"><input type="hidden" name="action" value="save_product"><input type="hidden" name="id" value="<?=$eid?>"><input name="name" required placeholder="نام محصول" value="<?=$ename?>"><input name="category" required placeholder="دسته‌بندی" value="<?=$ecat?>"><div class="two"><input name="price" type="number" required placeholder="قیمت" value="<?=$eprice?>"><input name="old_price" type="number" placeholder="قیمت قبلی" value="<?=$eold?>"></div><input name="stock" type="number" required placeholder="موجودی" value="<?=$estock?>"><input name="image" placeholder="مسیر تصویر یا URL" value="<?=$eimage?>"><textarea name="description" placeholder="توضیحات"><?=$edesc?></textarea><label><input type="checkbox" name="active" <?=$eactive?>> نمایش محصول</label><button class="btn">ذخیره محصول</button></form></section>
<section><h2>کد تخفیف</h2><form class="form compact" method="post"><input type="hidden" name="action" value="coupon"><input name="code" required placeholder="مثلاً WELCOME20"><select name="type"><option value="percent">درصدی</option><option value="fixed">مبلغ ثابت</option></select><input name="value" type="number" required placeholder="مقدار"><button class="btn">افزودن کد</button></form><div class="notice">نمونه فعال: WELCOME10</div></section>
</div>
<h2>محصولات</h2><div class="table-wrap"><table class="table"><tr><th>محصول</th><th>دسته</th><th>قیمت</th><th>موجودی</th><th>عملیات</th></tr><?php foreach($products as $p):?><tr><td><?=h($p['name'])?></td><td><?=h($p['category'])?></td><td><?=number_format($p['price'])?></td><td><?=h($p['stock'])?></td><td><a class="mini" href="?edit=<?=$p['id']?>">ویرایش</a> <form method="post" style="display:inline"><input type="hidden" name="action" value="delete_product"><input type="hidden" name="id" value="<?=$p['id']?>"><button class="mini danger" onclick="return confirm('حذف شود؟')">حذف</button></form></td></tr><?php endforeach;?></table></div>
<h2>سفارش‌ها</h2><div class="table-wrap"><table class="table"><tr><th>شماره</th><th>مشتری</th><th>مبلغ</th><th>پرداخت</th><th>وضعیت</th><th>تغییر</th></tr><?php foreach(array_reverse($orders) as $o):?><tr><td><?=h($o['id'])?></td><td><?=h($o['customer']['name'])?><br><?=h($o['customer']['mobile'])?></td><td><?=number_format($o['total'])?></td><td><?=h($o['payment'])?></td><td><?=h($o['status'])?></td><td><form method="post"><input type="hidden" name="action" value="status_order"><input type="hidden" name="id" value="<?=h($o['id'])?>"><select name="status" onchange="this.form.submit()"><option>جدید</option><option>در حال آماده‌سازی</option><option>ارسال شد</option><option>تحویل شد</option><option>لغو شد</option></select></form></td></tr><?php endforeach;?></table></div>
</main></body></html>
