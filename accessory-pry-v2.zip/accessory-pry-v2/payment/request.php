<?php
session_start();
$config=require __DIR__.'/../config/config.php';
$products=json_decode(file_get_contents(__DIR__.'/../storage/products.json'),true)?:[];
$cart=$_SESSION['cart']??[];$coupon=$_SESSION['coupon']??null;$subtotal=0;$items=[];
foreach($cart as $id=>$q){$q=max(0,(int)$q);foreach($products as $p){if((string)$p['id']===(string)$id&&$q>0&&$p['active']&&$p['stock']>0){$q=min($q,(int)$p['stock']);$items[]=['id'=>$p['id'],'name'=>$p['name'],'price'=>$p['price'],'q'=>$q];$subtotal += $p['price']*$q;}}}
$discount=$coupon?($coupon['type']==='percent'?round($subtotal*$coupon['value']/100):min($subtotal,(int)$coupon['value'])):0;$total=$subtotal-$discount+$config['shipping_fee'];
$name=trim($_POST['name']??'');$mobile=trim($_POST['mobile']??'');$address=trim($_POST['address']??'');$postal=trim($_POST['postal']??'');$email=trim($_POST['email']??'');
if(!$items||!$name||!preg_match('/^09\d{9}$/',$mobile)||!$address)die('اطلاعات سفارش کامل نیست.');
$orderId='PRY-'.date('ymdHis').'-'.random_int(100,999);$order=['id'=>$orderId,'date'=>date('c'),'status'=>'در انتظار پرداخت','payment'=>'در انتظار','customer'=>compact('name','mobile','address','postal','email'),'items'=>$items,'subtotal'=>$subtotal,'discount'=>$discount,'shipping'=>$config['shipping_fee'],'total'=>$total];
if(str_contains($config['zarinpal']['merchant_id'],'YOUR-')){$_SESSION['pending_order']=$order;header('Location:verify.php?demo=1');exit;}
$payload=['merchant_id'=>$config['zarinpal']['merchant_id'],'amount'=>$total*10,'currency'=>'IRT','description'=>'خرید از اکسسوری پری - '.$orderId,'callback_url'=>rtrim($config['site_url'],'/').'/payment/verify.php','metadata'=>['mobile'=>$mobile,'email'=>$email,'order_id'=>$orderId]];
$endpoint=$config['zarinpal']['sandbox']?'https://sandbox.zarinpal.com/pg/v4/payment/request.json':'https://payment.zarinpal.com/pg/v4/payment/request.json';$ch=curl_init($endpoint);curl_setopt_array($ch,[CURLOPT_POST=>1,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json'],CURLOPT_RETURNTRANSFER=>1,CURLOPT_TIMEOUT=>20]);$res=curl_exec($ch);curl_close($ch);$j=json_decode($res,true);$code=$j['data']['code']??-1;if($code==100){$order['authority']=$j['data']['authority'];$_SESSION['pending_order']=$order;$auth=$order['authority'];$base=$config['zarinpal']['sandbox']?'https://sandbox.zarinpal.com/pg/StartPay/':'https://www.zarinpal.com/pg/StartPay/';header('Location:'.$base.$auth);exit;}die('خطا در اتصال به درگاه. کد: '.htmlspecialchars((string)$code));
